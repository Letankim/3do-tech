#!/bin/bash
# GoCaiDat_Mac.sh
# Gỡ Add-in Chuẩn hóa thể thức văn bản (Word & Excel) trên macOS.
# Chỉ xóa file add-in và file tạm của nó; không đụng tới văn bản hay cài đặt khác của Office.

echo "=============================================================================="
echo "        GỠ CÀI ĐẶT ADD-IN CHUẨN HÓA THỂ THỨC VĂN BẢN - WORD & EXCEL (macOS)"
echo "=============================================================================="

OFFICE_DIR="$HOME/Library/Group Containers/UBF8T346G9.Office"

# 0. Thử thoát Word / Excel. Không thoát được (đang hỏi lưu bài, hoặc chưa cho Terminal điều khiển)
#    thì VẪN gỡ tiếp: xóa file khi app đang mở vẫn được, chỉ cần thoát hẳn sau đó là hết nút.
CON_MO=""
for APP in "Microsoft Word" "Microsoft Excel"; do
    if pgrep -xq "$APP"; then
        echo "[*] Đang thoát $APP (nhớ lưu bài trước)..."
        osascript -e "tell application \"$APP\" to quit" >/dev/null 2>&1
        for _ in 1 2 3 4 5 6 7 8 9 10; do
            pgrep -xq "$APP" || break
            sleep 1
        done
        pgrep -xq "$APP" && CON_MO="$CON_MO $APP,"
    fi
done

if [ -d "$OFFICE_DIR" ] && ! ls "$OFFICE_DIR" >/dev/null 2>&1; then
    echo "[!] Terminal chưa được phép đọc thư mục Office."
    echo "    Vào Cài đặt hệ thống > Quyền riêng tư & Bảo mật, cho phép Terminal rồi chạy lại."
    exit 1
fi

DA_GO=0
xoa() {
    if [ -f "$1" ]; then
        rm -f "$1" && echo "[-] Đã xóa: $1" && DA_GO=1
    fi
}

# 1. Xóa add-in trong thư mục Office: Startup (bộ cài chép vào) và Add-Ins (Excel tự chép vào
#    khi thêm add-in bằng tay qua Công cụ > Phần bổ trợ Excel > Duyệt). Tên thư mục có hoặc
#    không có đuôi .localized; tên file viết hoa hay thường đều xóa.
for uc in "User Content.localized" "User Content"; do
    [ -d "$OFFICE_DIR/$uc" ] || continue
    while IFS= read -r f; do
        xoa "$f"
    done < <(find "$OFFICE_DIR/$uc" -maxdepth 3 -type f \
                \( -iname 'ChuanHoa_VanBanDang*.dotm' -o -iname 'ChuanHoa_Excel*.xlam' \) 2>/dev/null)
done

# 2. Bản Excel phụ bộ cài chép vào thư mục người dùng (kèm file khóa ~$ Excel để lại),
#    và file tạm của nút Cập nhật (Office chạy trong sandbox nên có thể nằm trong Containers).
xoa "$HOME/chuanhoa_excel.xlam"
xoa "$HOME/~\$chuanhoa_excel.xlam"
for d in "$HOME" "$HOME/Library/Containers/com.microsoft.Word/Data" "$HOME/Library/Containers/com.microsoft.Excel/Data"; do
    xoa "$d/cn_capnhat_WORD.tmp"
    xoa "$d/cn_capnhat_EXCEL.tmp"
done

echo ""
echo "=============================================================================="
if [ "$DA_GO" = 1 ]; then
    echo "                   GỠ CÀI ĐẶT THÀNH CÔNG!"
else
    echo "Không tìm thấy file add-in nào trên máy (có thể đã gỡ trước đó)."
fi
if [ -n "$CON_MO" ]; then
    echo ""
    echo "[!] Còn đang mở:${CON_MO%,}. Lưu bài rồi THOÁT HẲN bằng Cmd+Q để các nút biến mất."
fi
echo ""
echo "Mở lại Word / Excel: nhóm [THỂ THỨC VĂN BẢN] và nút [Chuẩn Hóa Trang In] đã biến mất."
echo "Nếu Excel báo không tìm thấy chuanhoa_excel.xlam: vào Công cụ > Phần bổ trợ Excel,"
echo "bỏ tích ChuanHoa_Excel rồi bấm OK (chỉ cần làm 1 lần)."
echo "=============================================================================="
