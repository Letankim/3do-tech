#!/bin/bash
# Go ca hai: add-in roi dich vu OfficePartyEngine.
D="$(cd "$(dirname "$0")" && pwd)"
bash "$D/GoCaiDat_Mac.sh"
bash "$D/GoCai_Engine_Mac.sh"
