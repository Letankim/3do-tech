#!/bin/bash
# Go ca hai: add-in roi dich vu OfficePartyEngine (cac tep trong thanh_phan).
D="$(cd "$(dirname "$0")" && pwd)/thanh_phan"
[ -d "$D" ] || { echo "[!] Khong thay thu muc thanh_phan canh GoCai_Mac.sh."; exit 1; }
bash "$D/GoCaiDat_Mac.sh"
bash "$D/GoCai_Engine_Mac.sh"
