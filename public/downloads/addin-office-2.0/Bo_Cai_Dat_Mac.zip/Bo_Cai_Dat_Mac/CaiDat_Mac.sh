#!/bin/bash
# Cai ca hai: dich vu OfficePartyEngine roi add-in Word / Excel.
D="$(cd "$(dirname "$0")" && pwd)"
bash "$D/CaiDat_Engine_Mac.sh" || exit 1
bash "$D/CaiDat_AddIn_Mac.sh"
