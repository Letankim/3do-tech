#!/bin/bash
# Cai ca hai: dich vu OfficePartyEngine roi add-in Word / Excel (cac tep trong thanh_phan).
D="$(cd "$(dirname "$0")" && pwd)/thanh_phan"
[ -d "$D" ] || { echo "[!] Khong thay thu muc thanh_phan canh CaiDat_Mac.sh: giai nen ca file .zip roi chay lai."; exit 1; }
bash "$D/CaiDat_Engine_Mac.sh" || exit 1
bash "$D/CaiDat_AddIn_Mac.sh"
