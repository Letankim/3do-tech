#!/bin/bash
# Go OfficePartyEngine khoi macOS: dung engine, bo tu chay, xoa dung cac file bo cai da dat.
set -u
D="$HOME/Library/Application Support/OfficePartySuite"
LABEL="com.officepartysuite.engine"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1 && echo "[+] Da dung engine"
rm -f "$PLIST" && echo "[+] Da bo tu chay khi dang nhap"
rm -f "$HOME/Library/Application Scripts/com.microsoft.Word/OPSEngine.scpt" && echo "[+] Da xoa script cau noi cua Word"
rm -f "$D/OfficePartyEngine" "$D/engine.cfg" "$D/engine.cfg.tmp" "$D/engine.log" "$D/launchd.log" "$D/caidat_pkg.log"
# tep tam cua hop thoai / cua so thanh % (internal/hop, internal/tientrinh)
rm -f "$D/OPSHop" "$D/hop_chu_mac.js" "$D/hop_mac.js" "$D"/hop_*.html "$D"/hop_*.html.kq "$D/tien_trinh.html" "$D/tien_trinh.txt" "$D/tien_trinh.txt.tmp" "$D/tien_trinh_mac.js"
# tep tai ve / cho thay cua lan tu cap nhat (internal/capnhat)
rm -rf "$D/capnhat"
rm -f "$D/OfficePartyEngine.ops_moi"
# Chi xoa thu muc neu khong con file nao khac
rmdir "$D" 2>/dev/null
echo "[+] Da xoa chuong trinh va cau hinh"
echo "Go cai xong."
