#!/bin/bash
# Cai OfficePartyEngine (ban thu nghiem) cho nguoi dung hien tai tren macOS. Khong can quyen admin.
#   - Chep chuong trinh vao ~/Library/Application Support/OfficePartySuite/
#   - Go co "tai tu Internet" (quarantine) tren chuong trinh vua chep
#   - Tao file cau hinh engine.cfg (cong + ma bi mat sinh ngau nhien)
#   - Dat script cau noi cho Word: ~/Library/Application Scripts/com.microsoft.Word/OPSEngine.scpt
#   - Dang ky LaunchAgent de engine tu chay khi dang nhap
# Go cai: GoCai_Engine_Mac.sh
set -u
SRC="$(cd "$(dirname "$0")" && pwd)"
D="$HOME/Library/Application Support/OfficePartySuite"
SCPT_DIR="$HOME/Library/Application Scripts/com.microsoft.Word"
LABEL="com.officepartysuite.engine"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
BIN="$D/OfficePartyEngine"

echo "======================================================"
echo "  CAI DAT OFFICEPARTYENGINE (BAN THU NGHIEM) - macOS"
echo "======================================================"

[ -f "$SRC/OfficePartyEngine" ] || { echo "[!] Khong thay file OfficePartyEngine canh bo cai."; exit 1; }
[ -f "$SRC/OPSEngine.applescript" ] || { echo "[!] Khong thay file OPSEngine.applescript canh bo cai."; exit 1; }

# 1. Dung ban dang chay (neu cai lai)
launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1

# 2. Chep chuong trinh
mkdir -p "$D" && chmod 700 "$D"
cp -f "$SRC/OfficePartyEngine" "$BIN" || { echo "[!] Khong chep duoc chuong trinh."; exit 1; }
chmod 755 "$BIN"
xattr -cr "$BIN"
echo "[+] Da chep chuong trinh: $BIN"

# 3. Cau hinh (giu ma cu neu cai lai; GoCai xoa file nay)
"$BIN" khoi-tao >/dev/null || { echo "[!] Khong tao duoc engine.cfg."; exit 1; }
echo "[+] Da tao cau hinh: $D/engine.cfg"

# 4. Script cau noi cho Word (AppleScriptTask chi doc script trong thu muc nay)
mkdir -p "$SCPT_DIR"
osacompile -o "$SCPT_DIR/OPSEngine.scpt" "$SRC/OPSEngine.applescript" || { echo "[!] Khong bien dich duoc OPSEngine.applescript."; exit 1; }
echo "[+] Da dat script cho Word: $SCPT_DIR/OPSEngine.scpt"

# 5. Tu chay khi dang nhap (chi cho nguoi dung nay)
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array><string>$BIN</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>ProcessType</key><string>Background</string>
  <key>StandardErrorPath</key><string>$D/launchd.log</string>
</dict>
</plist>
EOF
launchctl bootstrap "gui/$(id -u)" "$PLIST" || { echo "[!] Khong dang ky duoc LaunchAgent."; exit 1; }
echo "[+] Da dang ky tu chay khi dang nhap: $PLIST"

# 6. Kiem tra
# Doc lai cong / ma moi lan: cong mac dinh dang ban thi engine chuyen sang cong du phong va ghi lai engine.cfg.
# curl -f: tra loi loi HTTP (vd "sai ma bi mat" cua mot engine khac dang giu cong) khong tinh la thanh cong.
HDR=$(mktemp -t opsengine); trap 'rm -f "$HDR"' EXIT
for i in 1 2 3 4 5 6 7 8 9 10; do
  PORT=$(sed -n 's/^port=//p' "$D/engine.cfg" | tr -d '\r')
  printf 'X-OPS-Token: %s\n' "$(sed -n 's/^token=//p' "$D/engine.cfg" | tr -d '\r')" > "$HDR"
  R=$(curl -sf -m 2 --noproxy '*' -H @"$HDR" "http://127.0.0.1:$PORT/health") && break
  R=""
  sleep 0.5
done
if [ -n "${R:-}" ]; then
  echo "[+] Engine dang chay o 127.0.0.1:$PORT -> $R"
  echo "======================================================"
  echo "  CAI DAT THANH CONG"
  echo "======================================================"
else
  echo "[!] Engine chua tra loi. Xem $D/engine.log va $D/launchd.log"
  exit 1
fi
