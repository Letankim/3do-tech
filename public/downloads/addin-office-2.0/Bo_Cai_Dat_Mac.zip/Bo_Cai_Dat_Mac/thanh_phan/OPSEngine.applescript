-- OPSEngine.applescript
-- Cau noi HTTP cho add-in Word Mac (VBA tren Mac khong co doi tuong HTTP).
-- Bo cai bien dich file nay thanh OPSEngine.scpt va dat vao:
--   ~/Library/Application Scripts/com.microsoft.Word/OPSEngine.scpt
-- VBA goi: AppleScriptTask("OPSEngine.scpt", "goiEngine", method & LF & path & LF & body)
-- Tra ve: "<ma HTTP>" & LF & noi dung phan hoi; ma 0 = khong ket noi duoc engine.
--
-- goiEngine goi THANG engine bang Foundation (NSURLConnection, AppleScriptObjC), khong "do shell script": do trong Word
-- 15/11/2026 lan gui co noi dung (POST) mat ~0,4 s thay vi ~0,9 s qua binary (ghi tep tam + chay tien trinh), GET ~0,35 s thay vi
-- ~0,4 s. Khong ket noi duoc (engine chua chay...) thi lui ve goiEngineBinary: chay binary OfficePartyEngine o che do client
-- ("OfficePartyEngine goi ..."), binary tu nho launchd bat lai engine roi thu them mot lan.

use AppleScript version "2.4"
use framework "Foundation"
use scripting additions

on goiEngine(thamSo)
	set kq to my goiTrucTiep(thamSo)
	if kq is missing value then return my goiEngineBinary(thamSo)
	return kq
end goiEngine

-- HTTP thang toi 127.0.0.1:<cong> (cong + ma bi mat doc tu engine.cfg). missing value = khong ket noi duoc.
on goiTrucTiep(thamSo)
	try
		set {phuongThuc, duongDan, noiDung} to my tachThamSo(thamSo)
		set LF to (ASCII character 10)
		if duongDan does not start with "/" then return "0" & LF & "duong dan khong hop le"
		set cfg to my docCauHinh((POSIX path of (path to home folder)) & "Library/Application Support/OfficePartySuite/engine.cfg")
		if cfg is missing value then return missing value
		set {cong, maBiMat} to cfg
		set u to current application's NSURL's URLWithString:("http://127.0.0.1:" & cong & duongDan)
		-- hop thoai (/hop/...) doi nguoi dung dong: cho toi 4 gio; con lai 60 giay
		set han to 60
		if duongDan starts with "/hop/" then set han to 14400
		set rq to current application's NSMutableURLRequest's requestWithURL:u cachePolicy:1 timeoutInterval:han
		rq's setHTTPMethod:phuongThuc
		rq's setValue:maBiMat forHTTPHeaderField:"X-OPS-Token"
		if noiDung is not "" then
			rq's setValue:"application/json; charset=utf-8" forHTTPHeaderField:"Content-Type"
			rq's setHTTPBody:((current application's NSString's stringWithString:noiDung)'s dataUsingEncoding:(current application's NSUTF8StringEncoding))
		end if
		set {duLieu, phanHoi, loi} to current application's NSURLConnection's sendSynchronousRequest:rq returningResponse:(reference) |error|:(reference)
		if duLieu is missing value then return missing value
		set chu to (current application's NSString's alloc()'s initWithData:duLieu encoding:(current application's NSUTF8StringEncoding)) as text
		return ((phanHoi's statusCode()) as text) & LF & chu
	on error
		return missing value
	end try
end goiTrucTiep

on goiEngineBinary(thamSo)
	set {phuongThuc, duongDan, noiDung} to my tachThamSo(thamSo)
	set LF to (ASCII character 10)
	if duongDan does not start with "/" then return "0" & LF & "duong dan khong hop le"
	set bin to (POSIX path of (path to home folder)) & "Library/Application Support/OfficePartySuite/OfficePartyEngine"
	set lenh to quoted form of bin & " goi " & quoted form of phuongThuc & " " & quoted form of duongDan
	if noiDung is not "" then
		set f to (POSIX path of (path to temporary items)) & "opsengine-" & (random number from 10000000 to 99999999) & ".json"
		my ghiFile(f, noiDung)
		-- binary xoa file nay sau khi doc
		set lenh to lenh & " " & quoted form of f
	end if
	try
		return do shell script lenh without altering line endings
	on error e
		return "0" & LF & "khong chay duoc OfficePartyEngine: " & e
	end try
end goiEngineBinary

-- Ham rong de do do tre cua chinh AppleScriptTask (khong goi engine)
on ping(x)
	return "pong"
end ping

-- Ban cu dung curl (3 lan do shell script), chi de so sanh toc do
on goiEngineCurl(thamSo)
	set {phuongThuc, duongDan, noiDung} to my tachThamSo(thamSo)
	set LF to (ASCII character 10)
	if duongDan does not start with "/" then return "0" & LF & "duong dan khong hop le"
	set cfg to my docCauHinh((POSIX path of (path to home folder)) & "Library/Application Support/OfficePartySuite/engine.cfg")
	if cfg is missing value then return "0" & LF & "chua cai OfficePartyEngine (khong doc duoc engine.cfg)"
	set {cong, maBiMat} to cfg
	set tmpDir to do shell script "mktemp -d -t opsengine"
	set fVao to tmpDir & "/vao.json"
	set fRa to tmpDir & "/ra.txt"
	set fHdr to tmpDir & "/hdr.txt"
	-- Ma bi mat dua qua file header (curl -H @file) de khong hien tren dong lenh
	my ghiFile(fHdr, "X-OPS-Token: " & maBiMat & LF & "Content-Type: application/json; charset=utf-8" & LF)
	set lenh to "/usr/bin/curl -s -m 30 --noproxy '*' -o " & quoted form of fRa & " -w '%{http_code}' -H @" & quoted form of fHdr & " -X " & quoted form of phuongThuc
	if noiDung is not "" then
		my ghiFile(fVao, noiDung)
		set lenh to lenh & " --data-binary @" & quoted form of fVao
	end if
	set lenh to lenh & " " & quoted form of ("http://127.0.0.1:" & cong & duongDan)
	set ma to "0"
	set ketQua to ""
	try
		set ma to do shell script lenh
		set ketQua to (current application's NSString's stringWithContentsOfFile:fRa encoding:(current application's NSUTF8StringEncoding) |error|:(missing value)) as text
	on error loiCurl
		set ma to "0"
		set ketQua to "khong ket noi duoc engine: " & loiCurl
	end try
	do shell script "rm -rf " & quoted form of tmpDir
	return ma & LF & ketQua
end goiEngineCurl

-- "method LF path LF body" -> {method, path, body}; body co the chua LF
on tachThamSo(thamSo)
	set LF to (ASCII character 10)
	set AppleScript's text item delimiters to LF
	set ds to text items of thamSo
	set noiDung to ""
	if (count of ds) > 2 then set noiDung to (items 3 thru -1 of ds) as text
	set AppleScript's text item delimiters to ""
	return {item 1 of ds, item 2 of ds, noiDung}
end tachThamSo

-- Doc / ghi tep bang Foundation (script co "use framework": "POSIX file <bien>" khong dung duoc nhu script thuong)
on docCauHinh(duongDan)
	set noiDungCfg to current application's NSString's stringWithContentsOfFile:duongDan encoding:(current application's NSUTF8StringEncoding) |error|:(missing value)
	if noiDungCfg is missing value then return missing value
	set cong to ""
	set maBiMat to ""
	repeat with dong in paragraphs of (noiDungCfg as text)
		set d to dong as text
		if d starts with "port=" then set cong to text 6 thru -1 of d
		if d starts with "token=" then set maBiMat to text 7 thru -1 of d
	end repeat
	if cong is "" or (length of maBiMat) < 32 then return missing value
	return {cong, maBiMat}
end docCauHinh

on ghiFile(duongDan, noiDungGhi)
	set ok to (current application's NSString's stringWithString:noiDungGhi)'s writeToFile:duongDan atomically:true encoding:(current application's NSUTF8StringEncoding) |error|:(missing value)
	if not (ok as boolean) then error "khong ghi duoc " & duongDan
end ghiFile
