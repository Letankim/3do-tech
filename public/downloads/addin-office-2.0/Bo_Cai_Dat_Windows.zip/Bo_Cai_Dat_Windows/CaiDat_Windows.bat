@echo off
rem Cai ca hai: OfficePartyEngine roi add-in Word / Excel (cac tep trong thanh_phan).
call "%~dp0thanh_phan\CaiDat_Engine_Windows.bat" /goi
if errorlevel 1 exit /b 1
call "%~dp0thanh_phan\CaiDat_AddIn_Windows.bat"
