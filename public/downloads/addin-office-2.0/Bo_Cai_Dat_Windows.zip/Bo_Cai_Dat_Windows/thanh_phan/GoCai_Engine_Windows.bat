@echo off
chcp 65001 >nul
setlocal
echo Go OfficePartyEngine khoi may (nguoi dung hien tai)...
set "D=%LOCALAPPDATA%\OfficePartySuite"

:: Nho engine dang chay tu thoat (chinh engine lam, khong tat cuong buc)
if exist "%D%\OfficePartyEngine.exe" "%D%\OfficePartyEngine.exe" dung
if exist "%D%\webview2" rmdir /S /Q "%D%\webview2" >nul 2>&1
:: Tep cua lan tu cap nhat (internal/capnhat): goi cho thay, engine / thu vien cu da doi ten
if exist "%D%\capnhat" rmdir /S /Q "%D%\capnhat" >nul 2>&1
for %%f in (OfficePartyEngine.cu.exe WebView2Loader.cu.dll) do if exist "%D%\%%f" del /F /Q "%D%\%%f" >nul 2>&1
for %%f in (OfficePartyEngine.exe engine.cfg engine.cfg.tmp engine.log WebView2Loader.dll tien_trinh.html tien_trinh.txt tien_trinh.txt.tmp hop_donvi.html hop_tuychon.html hop_xacnhan.html) do if exist "%D%\%%f" del /F /Q "%D%\%%f" >nul 2>&1
if exist "%D%\OfficePartyEngine.exe" (
    echo [!] Chua xoa duoc OfficePartyEngine.exe ^(engine van dang chay^).
    echo     Hay dong Word, khoi dong lai may roi chay lai file nay.
) else (
    echo [+] Da xoa chuong trinh va cau hinh
)
:: Chi xoa thu muc neu khong con file nao khac
rmdir "%D%" >nul 2>&1
if exist "%TEMP%\ops_engine_ketqua.txt" del /F /Q "%TEMP%\ops_engine_ketqua.txt" >nul 2>&1
echo Go cai xong.
if /I not "%~1"=="/goi" pause
