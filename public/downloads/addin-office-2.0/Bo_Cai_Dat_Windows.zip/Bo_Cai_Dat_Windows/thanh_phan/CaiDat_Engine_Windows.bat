@echo off
chcp 65001 >nul
setlocal EnableExtensions
echo ======================================================
echo   CAI DAT OFFICEPARTYENGINE (BAN THU NGHIEM) - Windows
echo ======================================================
echo Cai cho nguoi dung hien tai, khong can quyen admin:
echo  - Chep OfficePartyEngine.exe vao %%LOCALAPPDATA%%\OfficePartySuite
echo  - Tao cau hinh engine.cfg (cong + ma bi mat ngau nhien) va chay engine
echo  - Khong tao loi tat hay lich tu chay: add-in Word tu bat engine khi can
echo Go cai: GoCai_Engine_Windows.bat
echo.

set "SRC=%~dp0"
set "D=%LOCALAPPDATA%\OfficePartySuite"
set "EXE=%D%\OfficePartyEngine.exe"

if not exist "%SRC%OfficePartyEngine.exe" (
    echo [!] Khong thay OfficePartyEngine.exe canh file cai dat.
    echo     Hay Giai nen ^(Extract All^) file .zip truoc roi chay lai.
    goto :LOI
)

:: 1. Cai lai: nho engine dang chay tu thoat (chinh engine lam, khong tat cuong buc) de chep de duoc file exe
if exist "%EXE%" "%EXE%" dung

:: 2. Chep chuong trinh
if not exist "%D%" mkdir "%D%"
copy /Y "%SRC%OfficePartyEngine.exe" "%EXE%" >nul 2>&1
if errorlevel 1 (
    echo [!] Khong chep duoc OfficePartyEngine.exe.
    echo     - Dong Word roi chay lai file nay.
    echo     - Neu Windows Security bao co virus: day la file chua ky so, xem muc
    echo       "Neu Defender chan" trong HUONG_DAN_THU.txt.
    goto :LOI
)
echo [+] Da chep chuong trinh: %EXE%
if exist "%SRC%WebView2Loader.dll" copy /Y "%SRC%WebView2Loader.dll" "%D%\WebView2Loader.dll" >nul 2>&1

:: 3. Tao cau hinh (giu ma cu neu cai lai) va chay engine; engine tu doi toi khi san sang (toi da 10 giay)
"%EXE%" bat-dau
if errorlevel 1 (
    echo [!] Engine chua chay duoc.
    echo     - Xem nhat ky: %D%\engine.log
    echo     - Neu Windows Security chan / xoa file: xem HUONG_DAN_THU.txt.
    goto :LOI
)
echo [+] Da tao cau hinh: %D%\engine.cfg
echo [+] Engine dang chay (chi nghe tren may nay, 127.0.0.1)
echo.
echo ======================================================
echo   CAI DAT ENGINE THANH CONG
echo ======================================================
if /I not "%~1"=="/goi" pause
exit /b 0

:LOI
echo.
pause
exit /b 1
