@echo off
chcp 65001 >nul
setlocal EnableExtensions
echo ======================================================
echo   CAI DAT OFFICEPARTYENGINE (BAN THU NGHIEM) - Windows
echo ======================================================
echo Cai cho nguoi dung hien tai, khong can quyen admin:
echo  - Chep OfficePartyEngine.exe vao %%LOCALAPPDATA%%\OfficePartySuite
echo  - Tao cau hinh engine.cfg (cong + ma bi mat ngau nhien) va chay engine
echo  - Khong tao loi tat hay lich tu chay: add-in Word tu bat engine khi can
echo Go cai: GoCai_Engine_Windows.bat
echo.

set "SRC=%~dp0"
set "D=%LOCALAPPDATA%\OfficePartySuite"
set "EXE=%D%\OfficePartyEngine.exe"

if not exist "%SRC%OfficePartyEngine.exe" (
    echo [!] Khong thay OfficePartyEngine.exe canh file cai dat.
    echo     Hay Giai nen ^(Extract All^) file .zip truoc roi chay lai.
    goto :LOI
)

:: 1. Cai lai: nho engine dang chay tu thoat (chinh engine lam, khong tat cuong buc) de chep de duoc file exe
if exist "%EXE%" echo [*] Dang nho engine cu tu thoat ^(toi da khoang 10 giay^)...
if exist "%EXE%" "%EXE%" dung

:: 2. Chep chuong trinh
:: Windows khong cho ghi de tep exe dang chay (engine cu chua thoat kip, tien trinh con hop thoai) hoac dang bi diet virus quet:
:: thu lai toi ~10 giay; tep cu giong het tep moi thi giu; cuoi cung doi ten tep cu sang .cu.exe (Windows cho doi ten tep dang
:: chay) roi chep tep moi - nhu bo cai mot tep (cmd/caidat thayTep). Tep .cu.exe duoc xoa o lan cai / cap nhat sau.
if not exist "%D%" mkdir "%D%"
if exist "%D%\OfficePartyEngine.cu.exe" del /F /Q "%D%\OfficePartyEngine.cu.exe" >nul 2>&1
set /a LAN=0
:CHEP
copy /Y "%SRC%OfficePartyEngine.exe" "%EXE%" >nul 2>&1
if not errorlevel 1 goto :DA_CHEP
set /a LAN+=1
if %LAN% LSS 10 (
    echo [*] Tep engine cu chua duoc nha, thu lai ^(%LAN%/10^)...
    ping -n 2 127.0.0.1 >nul
    goto :CHEP
)
fc /b "%SRC%OfficePartyEngine.exe" "%EXE%" >nul 2>&1
if not errorlevel 1 goto :DA_CHEP
if not exist "%D%\OfficePartyEngine.cu.exe" ren "%EXE%" OfficePartyEngine.cu.exe >nul 2>&1
copy /Y "%SRC%OfficePartyEngine.exe" "%EXE%" >nul 2>&1
if errorlevel 1 (
    if not exist "%EXE%" if exist "%D%\OfficePartyEngine.cu.exe" ren "%D%\OfficePartyEngine.cu.exe" OfficePartyEngine.exe >nul 2>&1
    echo [!] Khong chep duoc OfficePartyEngine.exe.
    echo     - Engine cu van dang chay: dong Word, mo Task Manager ^(Ctrl+Shift+Esc^), chon
    echo       OfficePartyEngine ^> End task ^(hoac khoi dong lai may^), roi chay lai file nay.
    echo     - Neu Windows Security bao co virus: day la file chua ky so, xem muc
    echo       "Neu Defender chan" trong HUONG_DAN_THU.txt.
    goto :LOI
)
:DA_CHEP
echo [+] Da chep chuong trinh: %EXE%
if exist "%SRC%WebView2Loader.dll" copy /Y "%SRC%WebView2Loader.dll" "%D%\WebView2Loader.dll" >nul 2>&1

:: 3. Tao cau hinh (giu ma cu neu cai lai) va chay engine; engine tu doi toi khi san sang (toi da 10 giay)
"%EXE%" bat-dau
if errorlevel 1 (
    echo [!] Engine chua chay duoc.
    echo     - Xem nhat ky: %D%\engine.log
    echo     - Neu Windows Security chan / xoa file: xem HUONG_DAN_THU.txt.
    goto :LOI
)
echo [+] Da tao cau hinh: %D%\engine.cfg
echo [+] Engine dang chay (chi nghe tren may nay, 127.0.0.1)
echo.
echo ======================================================
echo   CAI DAT ENGINE THANH CONG
echo ======================================================
if /I not "%~1"=="/goi" pause
exit /b 0

:LOI
echo.
pause
exit /b 1
