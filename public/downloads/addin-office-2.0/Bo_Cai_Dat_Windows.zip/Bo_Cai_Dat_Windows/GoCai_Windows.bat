@echo off
rem Go ca hai: OfficePartyEngine roi add-in Word / Excel (cac tep trong thanh_phan).
call "%~dp0thanh_phan\GoCai_Engine_Windows.bat" /goi
call "%~dp0thanh_phan\GoCaiDat_Windows.bat"
